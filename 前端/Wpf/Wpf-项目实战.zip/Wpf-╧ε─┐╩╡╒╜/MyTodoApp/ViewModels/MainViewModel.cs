﻿using MyTodoApp.Extensions;
using MyTodoApp.Models;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTodoApp.ViewModels
{
    public class MainViewModel:BindableBase 
    {
        public MainViewModel(IRegionManager regionManager)
        {
            MenuBars = new ObservableCollection<MenuBar>();

            CreateMenuBar();
        

            NavigateCommand = new DelegateCommand<MenuBar>(Navigate);
            this.regionManager = regionManager;
            GoBackCommand = new DelegateCommand(() =>
            {
                if (journal != null && journal.CanGoBack)
                    journal.GoBack();
            });
            GoForwardCommand = new DelegateCommand(() =>
            {
                if (journal != null&& journal.CanGoForward)
                    journal.GoForward();
            });
        }

        private void Navigate(MenuBar obj)
        {
            if (obj==null||string.IsNullOrWhiteSpace(obj.NameSpace))
                return;
            regionManager.Regions[PrismManager.MainViewRegionName].RequestNavigate(obj.NameSpace, back => {
                journal = back.Context.NavigationService.Journal;//获取导航日志
            });//获取到前台注册的Region区域 并做请求导航到标题

            
        }
        #region 一）、驱动整个导航的命令
        public DelegateCommand<MenuBar> NavigateCommand { get; private set; }

        private readonly IRegionManager regionManager;

        private IRegionNavigationJournal journal;
        public DelegateCommand GoBackCommand { get; set; }
        public DelegateCommand GoForwardCommand { get; set; }
        #endregion

        #region 数据双向绑定

        private ObservableCollection<MenuBar> menuBars;
    
        public ObservableCollection<MenuBar> MenuBars
        {
            get { return menuBars; }
            set { menuBars = value; 
                RaisePropertyChanged(); }
        }
  

        void CreateMenuBar()
        {
            menuBars.Add(new MenuBar { Icon="Home",NameSpace="IndexView",Title="首页"});
            menuBars.Add(new MenuBar { Icon = "NotebookOutline", NameSpace = "TodoView", Title = "待办事项" });
            menuBars.Add(new MenuBar { Icon = "NotebookPlus", NameSpace = "MemoView", Title = "备忘录" });
            menuBars.Add(new MenuBar { Icon = "Cog", NameSpace = "SettingsView", Title = "设置" });
        }
      
        #endregion

    }
}
