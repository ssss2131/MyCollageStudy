﻿using MyTodoApp.Models;
using MyTodoApp.Service;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTodoApp.ViewModels
{
    public class MemoViewModel:BindableBase
    {
        public MemoViewModel()
        {
            CreateList();
            AddCommand = new DelegateCommand(add);
        }

        private ObservableCollection <MemoDto> memoDtos;
        private bool isRightDrawerOpen;
    

        public bool IsRightDrawerOpen
        {
            get { return isRightDrawerOpen; }
            set
            {
                isRightDrawerOpen = value;
                RaisePropertyChanged();
            }
        }

        public DelegateCommand AddCommand { get; private set; }
        public ObservableCollection<MemoDto> MemoDtos
        {
            get { return memoDtos; }
            set
            {
                memoDtos = value;
                RaisePropertyChanged();
            }
        }
        void CreateList()
        {
            memoDtos = new ObservableCollection<MemoDto>();
            for (int i = 0; i < 20; i++)
            {
                memoDtos.Add(new MemoDto { Content = "测试数据...", Title = "标题" + i });
            }
        }
        private void add()
        {
            IsRightDrawerOpen = !IsRightDrawerOpen;
        }
    }
}
