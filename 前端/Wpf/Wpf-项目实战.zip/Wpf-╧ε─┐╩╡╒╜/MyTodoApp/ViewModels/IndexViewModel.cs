﻿using MyTodoApp.Models;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTodoApp.ViewModels
{
    public class IndexViewModel: BindableBase
    {
        public IndexViewModel()
        {
            TaskBars = new ObservableCollection<TaskBar>();
            CreateTaskBars();
            CreateTest();
        }
        private ObservableCollection<TaskBar> taskBars;
        private ObservableCollection<MemoDto> memoDtos;
        private ObservableCollection<TodoDto> todoDtos;
        public ObservableCollection<TaskBar> TaskBars
        {
            get { return taskBars; }
            set { taskBars = value; RaisePropertyChanged(); }
        }
        public ObservableCollection<TodoDto> TodoDtos
        {
            get { return todoDtos; }
            set
            {
                todoDtos = value;
                RaisePropertyChanged();
            }
        }
       public ObservableCollection<MemoDto> MemoDtos
        {
            get { return memoDtos; }
            set
            {
                memoDtos = value;
                RaisePropertyChanged();
            }
        }

        void CreateTaskBars()
        {
            TaskBars.Add(new TaskBar { Color = "#FF0CA0FF", Content = "9", Icon = "ClockFast", Target = "", Title = "汇总" });
            TaskBars.Add(new TaskBar { Color = "#FF1ECA3A", Content = "9", Icon = "ClockCheckOutline", Target = "", Title = "已完成" });
            TaskBars.Add(new TaskBar { Color = "#FF02C6DC", Content = "100%", Icon = "CalendarTextOutline", Target = "ChartLineVariant", Title = "完成率" });
            TaskBars.Add(new TaskBar { Color = "#FFFFA000", Content = "19", Icon = "CalendarTextOutline", Target = "", Title = "备忘录" });
        }
        void CreateTest()
        {
            TodoDtos = new ObservableCollection<TodoDto>();
            MemoDtos = new ObservableCollection<MemoDto>();
            for (int i = 0; i < 10; i++)
            {
                memoDtos.Add(new MemoDto { Title = "备忘事项" + i, Content = "我的密码" });
                todoDtos.Add(new TodoDto { Title = "待办事项" + i, Content = "正在执行..." });
            }
        }
    }
}
