﻿using Example;
using MyTodo.Shared.Parameter;
using MyTodoApp.Models;
using MyTodoApp.Service;
using Prism.Commands;
using Prism.Mvvm;
 
using System.Collections.ObjectModel;
 
namespace MyTodoApp.ViewModels
{
    public class TodoViewModel:BindableBase
    {     
        public TodoViewModel(ITodoService service)
        {
            this.service = service;
            AddCommand = new DelegateCommand(add);
            CreateList();
        }
        private ObservableCollection<MyTodo.Shared.Dtos.TodoDto> todoDtos;
        private bool isRightDrawerOpen;
        private readonly ITodoService service;
      
        public bool IsRightDrawerOpen
        {
            get { return isRightDrawerOpen; }
            set { isRightDrawerOpen = value;
                RaisePropertyChanged();
            }
        }

        public DelegateCommand AddCommand { get; private set; }
        public ObservableCollection<MyTodo.Shared.Dtos.TodoDto> TodoDtos
        {
            get { return todoDtos; }
            set { todoDtos = value;
                RaisePropertyChanged();
            }
        }
        async void CreateList()
        {
            todoDtos = new ObservableCollection<MyTodo.Shared.Dtos.TodoDto>();
            var todoResult = await service.GetAllAsync(new QueryParameter()
            {
                PageIndex = 0,
                PageSize = 100
            });
            if (todoResult.Status)
            {
                todoDtos.Clear();
                foreach (var item in todoResult.Result.Items)
                {
                    todoDtos.Add(item);
                }
            }
        }
        private void add()
        {
            IsRightDrawerOpen = !IsRightDrawerOpen;
        }
    }
}
