﻿using MyTodo.Shared.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTodoApp.Service
{
    public class TodoService : BaseService<TodoDto>, ITodoService
    {
        public TodoService(HttpRestClient client, string serviceName) : base(client, serviceName)
        {
        }
    }
}
