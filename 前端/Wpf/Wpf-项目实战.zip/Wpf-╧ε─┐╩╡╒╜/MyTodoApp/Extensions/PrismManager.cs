﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTodoApp.Extensions
{
    public static class PrismManager
    {
        public static readonly string MainViewRegionName = "MainViewRegion";

        public static readonly string SettingsViewRegionName = "SettingsViewRegionName";
    }
}
