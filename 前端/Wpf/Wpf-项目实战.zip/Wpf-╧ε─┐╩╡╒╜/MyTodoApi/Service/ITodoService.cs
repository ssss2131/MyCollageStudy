﻿using MyTodo.Shared.Dtos;
using MyTodoApi.Context;
using System.Threading.Tasks;

namespace MyTodoApi.Service
{
    public interface ITodoService : IBaseService<TodoDto>
    {
        
    }
}
