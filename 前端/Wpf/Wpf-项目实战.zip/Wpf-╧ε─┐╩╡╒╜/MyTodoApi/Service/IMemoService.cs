﻿using MyTodo.Shared.Dtos;

namespace MyTodoApi.Service
{
    public interface IMemoService:IBaseService<MemoDto>
    {
    }
}
